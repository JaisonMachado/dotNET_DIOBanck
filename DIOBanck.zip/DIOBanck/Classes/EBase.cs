﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIOBanck.Classes
{
    public abstract class EBase
    {
        public int ContaNumero { get; protected set; }
    }
}
